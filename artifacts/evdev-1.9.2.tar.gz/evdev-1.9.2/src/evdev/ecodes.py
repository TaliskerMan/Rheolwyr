# When installed, this module is replaced by an ecodes.py generated at
# build time by genecodes_py.py (see build_ext in setup.py).

# This stub exists to make development of evdev itself more convenient.
from .ecodes_runtime import *
