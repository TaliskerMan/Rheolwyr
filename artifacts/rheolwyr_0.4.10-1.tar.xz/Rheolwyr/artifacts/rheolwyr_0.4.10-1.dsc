Format: 3.0 (native)
Source: rheolwyr
Binary: rheolwyr
Architecture: all
Version: 0.4.10-1
Maintainer: Chuck Talk <cwtalk1@gmail.com>
Homepage: https://github.com/TaliskerMan/rheolwyr
Standards-Version: 4.6.2
Build-Depends: debhelper-compat (= 13), python3-all, dh-python, pybuild-plugin-pyproject
Package-List:
 rheolwyr deb utils optional arch=all
Checksums-Sha1:
 d2cb4cf48c131b4ef4c988e09bd560c2beae898a 978704 rheolwyr_0.4.10-1.tar.xz
Checksums-Sha256:
 13ae8bd793bfc4f3791e32f63a0db5470d8cc307294ccd3c5b5ea72c99e1255c 978704 rheolwyr_0.4.10-1.tar.xz
Files:
 973a009f2aceb5446e34eead6298ba5d 978704 rheolwyr_0.4.10-1.tar.xz
