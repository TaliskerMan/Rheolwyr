#!/bin/bash
set -e

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}Rheolwyr Build Helper${NC}"
echo "---------------------"

# Set Maintainer Identity for GPG Signing and Changelog
export DEBFULLNAME="Chuck Talk"
export DEBEMAIL="cwtalk1@gmail.com"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 1. Install Dependencies
echo -e "\n${GREEN}[1/3] Checking Dependencies...${NC}"
MISSING_DEPS=()

if ! dpkg -s debhelper >/dev/null 2>&1; then MISSING_DEPS+=("debhelper"); fi
if ! dpkg -s dh-python >/dev/null 2>&1; then MISSING_DEPS+=("dh-python"); fi
if ! dpkg -s python3-all >/dev/null 2>&1; then MISSING_DEPS+=("python3-all"); fi
if ! dpkg -s pybuild-plugin-pyproject >/dev/null 2>&1; then MISSING_DEPS+=("pybuild-plugin-pyproject"); fi
if ! command_exists flatpak-builder; then MISSING_DEPS+=("flatpak-builder"); fi

if [ ${#MISSING_DEPS[@]} -ne 0 ]; then
    echo -e "${RED}Missing dependencies: ${MISSING_DEPS[*]}${NC}"
    read -p "Do you want to install them now? (sudo required) [y/N] " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo apt update
        sudo apt install -y "${MISSING_DEPS[@]}"
    else
        echo "Build cannot proceed without dependencies."
        exit 1
    fi
else
    echo "All dependencies installed."
fi

# 2. Build Debian Package
# Clean previous artifacts
rm -rf artifacts
mkdir -p artifacts

# 1.5 Increment Version
echo -e "\n${GREEN}[1.5/3] Incrementing Version...${NC}"
python3 scripts/increment_version.py

echo -e "\n${GREEN}[2/3] Building Debian Package (Signed)...${NC}"
# Removed -us -uc to allow signing, force sign with key
dpkg-buildpackage --sign-key="cwtalk1@gmail.com"

# Move artifacts to artifacts
mv ../rheolwyr_* artifacts/ 2>/dev/null || true
echo "Debian package built and moved to artifacts/"

# 3. Build Flatpak
echo -e "\n${GREEN}[3/3] Skipping Flatpak Build...${NC}"

# 4. Generate Hashes
echo -e "\n${GREEN}[4/4] Generating Checksums...${NC}"
cd artifacts
sha512sum * > SHA512SUMS
cd ..

echo -e "${GREEN}SUCCESS!${NC}"
ARTIFACT_PATH=$(realpath artifacts)
echo " - Artifacts are in: $ARTIFACT_PATH"
echo " - Checksum file: $ARTIFACT_PATH/SHA512SUMS"
